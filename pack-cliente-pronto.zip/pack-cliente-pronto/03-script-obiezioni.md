# Script obiezioni — 3 varianti

Usa questi script come **traccia**, non come copione. Adatta tono, esempi e numeri.  
Sostituisci i placeholder: `[NOME]`, `[SERVIZIO]`, `[PREZZO]`, `[TUO NOME]`, `[AZIENDA]`, `[RISULTATO TIPICO]` (solo fatti veri del tuo lavoro, mai guadagni inventati).

Struttura consigliata per ogni obiezione:  
**1)** Riconosci → **2)** Chiarisci → **3)** Inquadra il valore → **4)** Proponi un passo piccolo.

---

## 1) Obiezione PREZZO  
*«Costa troppo» / «Abbiamo trovato di meno» / «Fuori budget»*

### Versione A — Riconosci e riparti dal problema
«Capisco, [NOME]. Il prezzo è una decisione seria. Prima di parlare di numeri: il problema che mi hai descritto — [problema in una frase] — quanto vi sta costando in tempo o in opportunità se resta così per altri 2–3 mesi?  
Se ha senso affrontarlo, possiamo vedere cosa è davvero essenziale in [SERVIZIO] e cosa si può fare in una prima fase più contenuta.»

### Versione B — Confronto onesto (senza screditare)
«Ha senso confrontare. Spesso “di meno” include meno [consegna / supporto / revisioni / tempi]. Nel nostro [SERVIZIO] a [PREZZO] c’è esplicitamente: [incluso 1], [incluso 2], [incluso 3].  
Se il vostro vincolo è il budget, posso proporti [variante ridotta / pagamento rateale / solo fase 1] a [PREZZO ALTERNATIVO], così partite senza impegnare tutto subito. Ti interessa vedere quella opzione?»

### Versione C — Ancoraggio al next step (non allo sconto automatico)
«Non voglio convincerti a spendere ciò che non ha senso. Quello che posso fare è inviarti una proposta chiara con incluso/escluso e un’opzione entry.  
La guardi con calma e ci risentiamo [giorno]: se non torna, nessun problema. Ti va?»

**Da evitare:** scontare subito senza chiedere; attaccare il competitor; promettere ROI o «ti tornano indietro in X giorni».

---

## 2) Obiezione TEMPO  
*«Non ho tempo ora» / «Siamo sotto» / «Riparliamo tra mesi»*

### Versione A — Rispetta e riduci lo scope
«Ha senso: se siete sotto pressione, l’ultimo bisogno è un progetto pesante.  
Possiamo fare una versione minima: [kickoff breve / deliverable piccolo] in [tempo realistico, es. 1–2 settimane], con il minimo di meeting da parte vostra — di solito [X] ore vostre in tutto.  
Se anche quello è troppo, fissiamo un reminder a [data] e ti lascio materiale da leggere quando puoi.»

### Versione B — Costo del rinvio (senza drammi)
«Capito. Solo per chiarire: se rimandiamo di [1–2 mesi], [conseguenza concreta e vera del ritardo — es. restare senza processo / senza materiali / senza copertura].  
Non è un’urgenza artificiale: è per capire se “dopo” è davvero meglio o se una partenza leggera ora vi alleggerisce. Cosa preferisci?»

### Versione C — Micro-impegno
«Ok, niente progetto completo ora. Ti propongo solo questo: 20 minuti la prossima settimana per definire priorità e una checklist. Zero impegno di acquisto in quella call. Se dopo non ha senso, ci fermiamo. Ti va martedì o mercoledì?»

**Da evitare:** «Se non lo fai ora perdi l’occasione» senza scadenza vera; colpevolizzare; riempire il calendario di meeting inutili.

---

## 3) Obiezione «CI PENSO» / «Ne parlo col socio» / «Vi faccio sapere»
*Indecisione, bisogno di confrontarsi, cortesia di chiusura*

### Versione A — Rendi utile il “pensarci”
«Certo, [NOME]. “Ci penso” di solito significa che manca un pezzo: budget, tempi, o un sì da qualcun altro.  
Cosa ti aiuterebbe di più tra oggi e [giorno]: una proposta scritta in una pagina, un confronto a tre col [socio/decisore], o due opzioni di prezzo (completa vs essenziale)?»

### Versione B — Porta il decisore in stanza (con rispetto)
«Ha senso parlarne con [socio/responsabile]. Spesso è più veloce se siamo in tre per 15 minuti: così rispondo io ai dubbi e non ti tocca fare da intermediario.  
Preferisci che proponga io due slot, o preferisci girare tu la proposta e ci risentiamo [data]?»

### Versione C — Chiudi il loop (data + canale)
«Perfetto. Allora facciamo così: ti invio oggi un riepilogo con prezzo, incluso e prossimi passi.  
Io ti risento [giorno] alle [ora] per [telefono/mail] — non per pressarti, solo per capire se procediamo, rimandiamo o chiudiamo. Ti va bene quel giorno, o ne indichi un altro?»

**Frase di uscita pulita (se restano vaghi):**  
«Ok. Ti lascio il materiale. Se non ci sentiamo entro [data], considero il momento non adatto e non ti rimbalzo messaggi. Quando vorrete riprendere, basterà rispondere a quell’email.»

**Da evitare:** «Ultimi posti»; follow-up quotidiani aggressivi; fingere che una decisione urgente esista se non c’è.

---

## Schema rapido (da tenere sotto gli occhi in call)

| Obiezione | Prima frase | Passo successivo |
|-----------|-------------|------------------|
| Prezzo | «Capisco — vediamo cosa è essenziale.» | Opzione ridotta o proposta scritta |
| Tempo | «Ok — versione minima o data dopo.» | Scope ridotto o reminder |
| Ci penso | «Cosa manca per decidere?» | Materiale + data di ricontatto |

---

## Dopo l’obiezione

1. Annota sul `02-checklist-post-call.md` quale obiezione è rimasta aperta.  
2. Invia il riepilogo (Email 1 della sequenza).  
3. Non aggiungere sconti in email se non li hai già detti a voce.
