# 3 prompt extra — adatta tono e nicchia

Usa questi prompt con un’assistente AI (es. ChatGPT, Claude) **oppure** come guida manuale di riscrittura.  
Incolla lo script / email del pack e chiedi l’adattamento. Verifica sempre tu i fatti, i prezzi e il tono prima di inviare.

**Regola:** non chiedere all’AI di inventare risultati, ROI, testimonial o numeri clienti.

---

## Prompt 1 — Adatta alla nicchia

```
Sei un editor per PMI che vendono servizi. Riscrivi il testo qui sotto per la nicchia: [NICCHIA, es. studi di commercialisti / agenzie web / artigiani / consulenti HR].

Vincoli:
- Italiano professionale e chiaro
- Mantieni lo stesso obiettivo del messaggio (obiezione prezzo / follow-up / onboarding)
- Sostituisci esempi generici con esempi plausibili per la nicchia (senza inventare case study o cifre di guadagno)
- Tieni lunghezza simile all’originale (±15%)
- Lascia i placeholder tra parentesi quadre se servono ancora ([NOME], [PREZZO], ecc.)

Testo da adattare:
"""
[INCOLLA QUI script o email]
"""
```

---

## Prompt 2 — Cambia il tono (formale / diretto / caldo)

```
Riscrivi il testo seguente in tono: [FORMALE | DIRETTO | CALDO-PROFESSIONALE].

Regole:
- Lingua: italiano
- Niente urgenza falsa, niente “ultimo posto”, niente promesse di risultati o guadagni
- Una sola call-to-action, chiara
- Frasi corte; elimina ripetizioni
- Se il tono è FORMALE: dammi/Lei coerente; se DIRETTO: tu, concreto; se CALDO: tu, empatico ma non sdolcinato

Testo:
"""
[INCOLLA QUI]
"""

In output dammi solo la versione riscritta, pronta da usare.
```

---

## Prompt 3 — Personalizza su un prospect reale (brief → messaggi)

```
Ho un prospect. Usa SOLO le informazioni del brief (non inventare dettagli mancanti).
Se manca un’info, lascia un placeholder [DA COMPLETARE].

Brief:
- Nome: […]
- Azienda / ruolo: […]
- Problema detto: […]
- Servizio offerto: […]
- Prezzo: […]
- Obiezione principale: [prezzo | tempo | ci penso]
- Tono desiderato: […]
- Canale: [email | messaggio LinkedIn | call]

Compito:
1) Scrivi una risposta all’obiezione in 4–6 frasi (struttura: riconosci → chiarisci → valore → next step piccolo).
2) Scrivi l’Email 1 di riepilogo post-call (oggetto + corpo).
3) Elenca 3 domande di discovery ancora utili.

Divieti: ROI garantito, scarsità inventata, testimonial falsi, claim legali non verificati.
```

---

## Come usarli in 10 minuti

1. Scegli **un** pezzo del pack (es. script prezzo o Email 3).  
2. Lancia Prompt 1 **oppure** 2 (non entrambi insieme la prima volta).  
3. Rileggi ad alta voce: se non lo diresti in call, modifica.  
4. Per un cliente vero, usa il Prompt 3 con brief reale.  
5. Incolla il risultato finale nei tuoi template / CRM.

---

## Esempio di brief minimo (Prompt 3)

```
- Nome: Giulia
- Azienda / ruolo: titolare studio di progettazione
- Problema detto: fatica a dare follow-up ai preventivi
- Servizio offerto: setup sequenza email + script obiezioni
- Prezzo: €X
- Obiezione: tempo
- Tono: diretto
- Canale: email
```
