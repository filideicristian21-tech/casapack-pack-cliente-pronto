# Sequenza email — 5 tocchi di follow-up

Email già scritte, da personalizzare. Una CTA per messaggio.  
Tone: professionale, chiaro, senza pressioni false.

**Placeholders:** `[NOME]`, `[AZIENDA]`, `[SERVIZIO]`, `[PREZZO]`, `[TUO NOME]`, `[TUA AZIENDA]`, `[DATA CALL]`, `[NEXT STEP]`, `[LINK CALENDARIO o “proponi tu due slot”]`, `[LINK PROPOSTA]`.

**Tempistica consigliata** (modifica se il ciclo di vendita è più lungo):

| Email | Quando | Obiettivo |
|-------|--------|-----------|
| 1 | Stesso giorno della call (entro sera) | Riepilogo + next step |
| 2 | +2–3 giorni lavorativi | Valore / chiarimento |
| 3 | +5–7 giorni dalla call | Opzioni / sbloccare decisione |
| 4 | +10–12 giorni | Check soft + materiale utile |
| 5 | +14–18 giorni | Chiusura loop (sì / no / dopo) |

Se rispondono o dicono di no: **ferma la sequenza**.

---

## EMAIL 1 — Riepilogo post-call  
**Quando:** giorno della call  
**Oggetto:** Riepilogo call [DATA] — [SERVIZIO] e prossimi passi

Ciao [NOME],

grazie del tempo di oggi.

In sintesi, da quanto mi hai detto:
- obiettivo: […]
- vincolo principale: […]
- proposta discussa: [SERVIZIO] a [PREZZO] (una tantum / come da accordo)

**Prossimo passo proposto:** [NEXT STEP]  
Se ti torna, [LINK CALENDARIO / “dimmi due fasce orarie”].

In allegato / al link: [LINK PROPOSTA o “te la invio entro domani”].

A presto,  
[TUO NOME]  
[TUA AZIENDA]

---

## EMAIL 2 — Valore / risposta al dubbio  
**Quando:** +2–3 giorni lavorativi (solo se non hanno risposto)  
**Oggetto:** Un chiarimento su [SERVIZIO] (dopo la nostra call)

Ciao [NOME],

riprendo brevemente dopo la call di [DATA].

Spesso il dubbio resta su [prezzo / tempi / cosa è incluso]. In concreto, con [SERVIZIO] lavoriamo così:
1. […]
2. […]
3. […]

Cosa **non** è incluso (per evitare sorprese): […]

Se vuoi, rispondi pure a questa email con la domanda che ti è rimasta — anche in una riga.

Oppure fissiamo 15 minuti: [LINK CALENDARIO].

[TUO NOME]

---

## EMAIL 3 — Due opzioni (sblocca)  
**Quando:** +5–7 giorni dalla call  
**Oggetto:** Due strade possibili per [AZIENDA]

Ciao [NOME],

per renderti più semplice la decisione, ti lascio due opzioni chiare (stesso ambito [SERVIZIO]):

**Opzione A — Completa**  
[Cosa include in 2–3 bullet] — [PREZZO A]

**Opzione B — Essenziale**  
[Cosa include, più stretta] — [PREZZO B]

Entrambe partono con [kickoff / tempi]. Nessun impegno finché non ci dai conferma scritta.

Dimmi solo: A, B, o «ora non è il momento» — va bene anche la terza.

[TUO NOME]  
[TUA AZIENDA]

---

## EMAIL 4 — Check soft + materiale utile  
**Quando:** +10–12 giorni  
**Oggetto:** Materiale utile (senza impegno) — [TEMA]

Ciao [NOME],

non voglio riempirti la casella: ti lascio solo una cosa pratica legata a quanto ci siamo detti.

[Allegato / link: checklist, 1-pager, esempio di piano di lavoro — materiale vero tuo]

Se nel frattempo avete già scelto un’altra strada, nessun problema: una riga mi basta per chiudere il follow-up da parte mia.

Se invece volete riprendere, rispondete a questa email o scegliete uno slot: [LINK CALENDARIO].

[TUO NOME]

---

## EMAIL 5 — Chiusura del loop  
**Quando:** +14–18 giorni  
**Oggetto:** Chiudo il cerchio su [SERVIZIO]?

Ciao [NOME],

ultimo messaggio su questo filo, così non ti disturbo oltre.

Alla luce della call di [DATA], lascio aperte tre possibilità:
1. **Procediamo** — mi confermi opzione A o B e ti invio i passi di avvio  
2. **Rimandiamo** — mi indichi un mese in cui ha senso riparlare  
3. **Non ora** — chiudo qui senza altri follow-up

Basta una risposta con 1, 2 o 3.

Grazie ancora del tempo e del confronto.  
[TUO NOME]  
[TUA AZIENDA]

---

## Note d’uso

- **Oggetti:** corti, specifici, senza clickbait («URGENTE», «ultima chance»).
- **Allegati:** solo ciò che hai promesso; nomi file chiari (`Proposta-[Azienda]-data.pdf`).
- **CC:** aggiungi il decisore solo se il prospect è d’accordo.
- **CRM:** segna data di ogni invio e stop appena c’è risposta.
- **Limite:** queste email non garantiscono risposte o vendite; riducono il silenzio e chiariscono lo stato.
