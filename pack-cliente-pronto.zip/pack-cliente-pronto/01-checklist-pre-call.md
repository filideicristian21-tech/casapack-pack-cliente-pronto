# Checklist pre-call

Usa questa lista **prima** di ogni call commerciale o di discovery. Spunta i punti; lascia vuoto ciò che non applica. Obiettivo: arrivare preparato, non improvvisare.

**Cliente / prospect:** _______________________________  
**Data call:** _______________  **Durata prevista:** _______________  
**Canale:** □ Meet / Zoom  □ Telefono  □ Di persona  □ Altro: ________

---

## 1. Contesto (5 minuti)

- [ ] Ho riletto email, form o brief ricevuti
- [ ] So chi parla (ruolo, potere decisionale, chi altro decide)
- [ ] Ho chiaro il problema che dicono di avere (in una frase)
- [ ] Ho cercato sito / LinkedIn / materiale pubblico rilevante (max 5 min)
- [ ] So se è un primo contatto, un follow-up o una negoziazione

**Nota contesto (2–3 righe):**  
_______________________________________________________________  
_______________________________________________________________

---

## 2. Obiettivo della call (scegline UNO primario)

- [ ] Capire se c’è fit (discovery)
- [ ] Presentare proposta / preventivo
- [ ] Superare obiezioni e chiarire dubbi
- [ ] Chiudere (accordo verbale / next step firmato)
- [ ] Altro: _________________________________

**Esito minimo accettabile** (anche se non chiudono):  
_______________________________________________________________

**Esito ideale:**  
_______________________________________________________________

---

## 3. Offerta e numeri (da avere a portata di mano)

- [ ] Pacchetto / servizio proposto: _______________________________
- [ ] Prezzo (o range) che sono pronto a dire: € ________
- [ ] Cosa è incluso / escluso (in 3 bullet mentali)
- [ ] Tempi di consegna o avvio: _______________
- [ ] Alternative se il budget è stretto (piano ridotto / fasi): _______________
- [ ] Condizioni di pagamento che posso accettare: _______________

---

## 4. Domande da fare (scegline 4–6)

Spunta quelle che userai; non elencarle tutte a raffica.

- [ ] «Cosa vi ha spinto a parlarne proprio ora?»
- [ ] «Come gestite oggi [problema]? Cosa non funziona?»
- [ ] «Come misurerete se la soluzione ha funzionato?»
- [ ] «Chi altro deve essere d’accordo per procedere?»
- [ ] «Qual è il budget indicativo o il range che avete in mente?»
- [ ] «Entro quando vi serve una decisione / un avvio?»
- [ ] «Cosa vi ha fatto scartare altre opzioni in passato?»
- [ ] Altro: _________________________________

---

## 5. Obiezioni probabili (prepara 1 risposta ciascuno)

| Obiezione probabile | La mia risposta in 1–2 frasi |
|---------------------|-----------------------------|
| Prezzo              |                             |
| Tempo / priorità    |                             |
| «Ci penso» / Confrontiamo |                      |
| Altro: ________     |                             |

→ Dettaglio script: vedi `03-script-obiezioni.md`.

---

## 6. Logistica

- [ ] Link call / numero confermato e testato
- [ ] Calendario bloccato (buffer 5 min prima e dopo)
- [ ] Materiali aperti (proposta, slide, listino) — solo se servono
- [ ] Silenzio notifiche / cuffie / ambiente ok
- [ ] Ho un foglio o doc per appunti (o uso la post-call subito dopo)

---

## 7. Apertura e chiusura (bozza)

**Apertura (30 secondi):**  
«Grazie del tempo. Vorrei usare i prossimi X minuti per [obiettivo]. Va bene?»

**Chiusura prevista:**  
«In base a quanto detto, il passo successivo che propongo è […]. Ti va di fissarlo ora?»

---

## Check rapido (30 secondi prima di entrare)

- [ ] Obiettivo chiaro
- [ ] Prezzo e incluso/escluso chiari
- [ ] 4 domande pronte
- [ ] 1 risposta a obiezione prezzo
- [ ] Next step che voglio proporre definito

**Pronto.** Entra in call.
