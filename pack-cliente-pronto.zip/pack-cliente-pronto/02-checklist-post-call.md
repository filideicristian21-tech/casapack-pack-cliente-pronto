# Checklist post-call

Compila **entro 15 minuti** dalla fine della call, mentre i dettagli sono freschi. Ideale da stampare o tenere aperto a fianco.

**Cliente / prospect:** _______________________________  
**Data call:** _______________  **Durata reale:** _______________  
**Esito:** □ Positivo  □ In dubbio  □ Negativo  □ Da ricontattare

---

## 1. Cosa è successo (fatti, non interpretazioni)

**Problema / bisogno espresso (parole loro se possibile):**  
_______________________________________________________________  
_______________________________________________________________

**Decisori coinvolti:**  
_______________________________________________________________

**Budget / range citato:** □ Sì: € ______  □ No  □ Evitato  

**Tempistica citata:** □ Sì: ________  □ No  

**Concorrenza / alternative citate:**  
_______________________________________________________________

---

## 2. Segnali

**Segnali positivi** (interesse, urgenza, domande su avvio/pagamento):  
-  
-  

**Segnali di freno** (prezzo, timing, «ne parlo col socio», silenzi):  
-  
-  

**Obiezione principale rimasta aperta:**  
□ Prezzo  □ Tempo  □ «Ci penso»  □ Altro: ________  □ Nessuna

---

## 3. Accordo e next step

- [ ] Abbiamo definito un **prossimo passo concreto**
- [ ] Data / ora del next step: _______________
- [ ] Chi fa cosa:
  - Io: _________________________________
  - Loro: _______________________________
- [ ] Preventivo / proposta da inviare entro: _______________
- [ ] Contratto / ordine / acconto: □ Sì  □ No  □ Dopo proposta

**Se non c’è next step:** motivo e data in cui riproverò  
_______________________________________________________________

---

## 4. Azioni immediate (spunta e fai)

Ordine consigliato — non saltare il punto 1.

- [ ] **1. Appunti salvati** in cartella / CRM / nota cliente (questo file o copia)
- [ ] **2. Email di riepilogo** inviata entro oggi (o bozza pronta)  
      → vedi Email 1 in `04-sequenza-email-5-tocchi.md`
- [ ] **3. Materiali promessi** allegati o linkati (proposta, case, listino)
- [ ] **4. Promemoria calendario** per follow-up / call successiva
- [ ] **5. Se hanno detto sì** → inviare `05-scheda-onboarding.md` entro 24–48 h
- [ ] **6. Se sono in dubbio** → attivare sequenza 5 tocchi (date in calendario)
- [ ] **7. Se hanno detto no** → ringraziare, chiudere con grazia, eventuale ricontatto tra ___ mesi

---

## 5. Prezzo e condizioni (per non dimenticare)

| Voce | Valore |
|------|--------|
| Prezzo discusso | € |
| Sconto / variante | |
| Pagamento | |
| Tempi avviati | |
| Incluso / escluso critici | |

---

## 6. Lezione per la prossima call (1 riga)

Cosa rifarei uguale: _________________________________  
Cosa cambierei: _________________________________

---

## Riepilogo in 3 righe (per CRM)

1. _______________________________________________  
2. _______________________________________________  
3. _______________________________________________  

**Stato pipeline:** □ Lead caldo  □ Warm  □ Freddo  □ Chiuso vinto  □ Chiuso perso  

**Prossima azione automatica:** data ________ — azione ________________
