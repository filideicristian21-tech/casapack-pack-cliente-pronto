# Pack Cliente Pronto — Istruzioni d’uso (≈ 60 minuti)

Benvenuto. Questo pack ti dà testi e checklist già scritti per preparare una call commerciale, gestire le obiezioni più comuni e avviare l’onboarding del cliente. Non chiude i clienti al posto tuo: ti dà materiale da personalizzare. L’esito dipende da come lo usi e dal tuo mercato.

---

## Cosa c’è nello ZIP

| File | A cosa serve |
|------|----------------|
| `01-checklist-pre-call.md` | Preparazione prima della call |
| `02-checklist-post-call.md` | Cosa fare subito dopo la call |
| `03-script-obiezioni.md` | Risposte a prezzo / tempo / «ci penso» |
| `04-sequenza-email-5-tocchi.md` | Follow-up in 5 email |
| `05-scheda-onboarding.md` | Raccolta info per partire col lavoro |
| `06-prompt-extra.md` | Adatta tono e nicchia (anche con AI) |
| `README.md` | Indice, licenza, limiti |

---

## Percorso in 60 minuti

### Minuti 0–10 — Orientati
1. Apri questo file e il `README.md`.
2. Decidi **un** caso reale: un prospect o un cliente con cui hai una call nei prossimi giorni.
3. Annota: settore, servizio offerto, prezzo indicativo, ostacolo principale (prezzo / tempo / indecisione).

### Minuti 10–25 — Personalizza gli script
1. Apri `03-script-obiezioni.md`.
2. Sostituisci `[NOME]`, `[SERVIZIO]`, `[PREZZO]`, `[TUO NOME]`, `[AZIENDA]` con i tuoi dati.
3. Tieni solo le frasi che suonano naturali nella tua voce; cancella il resto.
4. Se serve un tono diverso (più formale / più diretto), usa un prompt da `06-prompt-extra.md`.

### Minuti 25–40 — Checklist e onboarding
1. Stampa o apri in parallelo `01-checklist-pre-call.md` e `02-checklist-post-call.md`.
2. Compila la pre-call per il caso scelto (anche a mano).
3. Compila `05-scheda-onboarding.md` in bozza: così sai già cosa chiedere se chiudono.

### Minuti 40–55 — Sequenza email
1. Apri `04-sequenza-email-5-tocchi.md`.
2. Personalizza oggetto e corpo delle 5 email.
3. Caricale nel tuo strumento (Gmail bozze, CRM, sequenza manuale) con le pause indicate.
4. Non inviare tutte insieme: rispetta i giorni tra un tocco e l’altro.

### Minuti 55–60 — Check finale
- [ ] Nomi e prezzi corretti (niente placeholder lasciati)
- [ ] Una sola CTA chiara per email
- [ ] Checklist post-call pronta da usare subito dopo la call
- [ ] Scheda onboarding stampata o salvata in cartella cliente

---

## Come usare il pack nel tempo

1. **Prima della call** → checklist pre-call + 1–2 script obiezioni rilevanti.
2. **Durante / subito dopo** → checklist post-call + invio Email 1 se previsto.
3. **Se dicono sì** → scheda onboarding entro 24–48 ore.
4. **Se restano in dubbio** → sequenza 5 tocchi, senza pressare oltre quanto scritto.

---

## Limiti onesti

- Nessuna garanzia di vendite, guadagni o chiusura.
- Gli script sono punti di partenza, non copioni da leggere a voce alta.
- Adatta sempre a contratto, conformità e regole del tuo settore.

Buon lavoro.  
— CasaPack
