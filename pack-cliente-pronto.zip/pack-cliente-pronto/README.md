# Pack Cliente Pronto — CasaPack

Kit digitale con checklist, script di risposta alle obiezioni, sequenza email di follow-up e scheda onboarding.  
**Pack pronti. Non template vuoti.** I testi sono già scritti: li personalizzi tu.

---

## Indice file

| # | File | Contenuto |
|---|------|-----------|
| 0 | `00-ISTRUZIONI.md` | Guida ~60 minuti: come usare il pack |
| 1 | `01-checklist-pre-call.md` | Preparazione prima della call |
| 2 | `02-checklist-post-call.md` | Azioni e appunti subito dopo la call |
| 3 | `03-script-obiezioni.md` | Script: prezzo / tempo / «ci penso» |
| 4 | `04-sequenza-email-5-tocchi.md` | 5 email di follow-up modificabili |
| 5 | `05-scheda-onboarding.md` | Scheda onboarding cliente (1 pagina) |
| 6 | `06-prompt-extra.md` | 3 prompt per adattare tono e nicchia |
| — | `README.md` | Questo indice + licenza |

---

## A chi è pensato

Freelancer, titolari di PMI e team piccoli che vendono **servizi** e vogliono materiali operativi per call, follow-up e avvio cliente — senza ripartire da un documento bianco.

---

## Come iniziare

1. Apri `00-ISTRUZIONI.md` e segui il percorso in ~60 minuti.  
2. Personalizza placeholder (`[NOME]`, `[PREZZO]`, ecc.).  
3. Usa checklist e script sulla prossima call reale.  
4. Attiva la sequenza email solo se non c’è risposta / decisione.

---

## Licenza d’uso

- **Consentito:** uso interno del tuo business o del tuo team (copie per collaboratori che lavorano con te).  
- **Non consentito:** rivendere, ridistribuire o pubblicare il pack (o parti sostanziali) come prodotto proprio; includerlo in marketplace o corsi a pagamento senza accordo scritto con CasaPack.  
- **Modifiche:** puoi adattare i testi per i tuoi clienti; la licenza resta non trasferibile.

---

## Limiti e disclaimer

- Questo pack è **materiale di lavoro**, non una consulenza legale, fiscale o finanziaria.  
- **Non garantisce** vendite, guadagni, ROI, numero di clienti o qualsiasi risultato di business.  
- L’esito dipende da mercato, offerta, esecuzione e contesto.  
- Verifica sempre prezzi, condizioni e conformità al tuo settore prima di inviare messaggi a terzi.

---

## Supporto prodotto

Problemi di download o file non corrispondenti alla descrizione: contatta il canale indicato sulla pagina di acquisto (Gumroad / Lemon Squeezy).  
Eventuale rimborso secondo i termini pubblicati al checkout (tipicamente 7 giorni se i file non si scaricano o non corrispondono).

---

## Versione

Pack Cliente Pronto — CasaPack · 2026  
Acquisto una tantum · aggiornamenti del pack entro 30 giorni dall’acquisto, se rilasciati.

© CasaPack. Tutti i diritti riservati sul testo originale del pack.
