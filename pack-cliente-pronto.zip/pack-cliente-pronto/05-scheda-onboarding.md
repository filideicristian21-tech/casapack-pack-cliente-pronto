# Scheda onboarding cliente (1 pagina)

Da compilare **insieme al cliente** o da fargli compilare entro 24–48 ore dall’accordo.  
Obiettivo: partire senza email a ping-pong.

**Data compilazione:** _______________  
**Compilata da:** □ Cliente  □ Noi (con call kickoff)  □ Mista

---

## A. Anagrafica e contatti

| Campo | Valore |
|-------|--------|
| Ragione sociale / nome | |
| Referente principale | |
| Ruolo | |
| Email operativa | |
| Telefono / chat preferita | |
| Altri contatti da coinvolgere | |
| Fatturazione (P. IVA / CF / indirizzo) | |
| PEC / SDI (se applicabile) | |

---

## B. Cosa abbiamo venduto (allineamento)

- **Servizio / pack / progetto:** _________________________________
- **Obiettivo del cliente (1 frase):** _____________________________
- **Fuori scope (cosa NON faremo):** _____________________________
- **Data avvio:** _______________  **Deadline / milestone 1:** _______________
- **Budget / prezzo concordato:** € ________  **Pagamento:** _______________
- **Canale di lavoro:** □ Email  □ Chat  □ Board  □ Call settimanale  □ Altro: ___

---

## C. Contesto operativo (il minimo indispensabile)

**Situazione attuale (come lavorano oggi):**  
_______________________________________________________________  
_______________________________________________________________

**Cosa deve cambiare a fine lavoro (esito osservabile, non generico):**  
_______________________________________________________________

**Vincoli** (tool obbligatori, brand, legale, accessi, stagionalità):  
_______________________________________________________________

**Materiali che il cliente deve consegnare** (spunta e data):  
- [ ] Logo / asset grafici — entro ________  
- [ ] Accessi (hosting, analytics, account) — entro ________  
- [ ] Documenti / brief esistenti — entro ________  
- [ ] Elenco contatti / prodotti / servizi — entro ________  
- [ ] Altro: ________________ — entro ________  

---

## D. Decisioni e comunicazione

- **Chi approva le consegne:** _________________________________
- **Tempo di feedback concordato:** □ 48 h  □ 5 gg lavorativi  □ Altro: ___
- **Frequenza aggiornamenti da parte nostra:** _____________________
- **Call di kickoff:** data ________  ora ________  link/luogo ________

---

## E. Rischi e preferenze

- **Cosa fare se un materiale ritarda:** ___________________________
- **Tono di comunicazione desiderato:** □ Formale  □ Diretto  □ Amichevole  
- **Cose da evitare** (parole, canali, orari): _______________________

---

## F. Checklist kickoff (interno + cliente)

- [ ] Contratto / ordine / conferma scritta ricevuta
- [ ] Acconto / primo pagamento (se previsto) ricevuto o datato
- [ ] Cartella condivisa / board creato
- [ ] Contatti aggiunti in rubrica / CRM
- [ ] Prima milestone e data scritti sopra
- [ ] Cliente ha ricevuto questa scheda compilata in copia

---

## G. Note libere (max 5 righe)

_______________________________________________________________  
_______________________________________________________________  
_______________________________________________________________  

---

**Firma / conferma email cliente (opzionale):** _______________  data: ________  

*Questa scheda organizza l’avvio del lavoro. Non sostituisce contratto o condizioni commerciali.*
